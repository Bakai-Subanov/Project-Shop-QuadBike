import React from "react";
import "./header.css"
import { Link } from "react-router-dom";

export default function Header() {
    const link = "text-xl font-bold";

    return ( 
    <div className=" flex items-center justify-between mb-5">
        <img className="" src="/images/logo.png" alt="" />
        <menu>
            <nav>
                <ul className=" flex gap-4">
                    <li><a className={link} href="/">Магазины</a></li>
                    <li><a className={link} href="/">Акции</a></li>
                    <li><a className={link} href="/">Доставка и оплата</a></li>
                </ul>
            </nav>
        </menu>
        <div>
            <Link to="/details">
                <img src="/images/Vector.svg" alt="" />
            </Link>
        </div>
    </div>
    );
}