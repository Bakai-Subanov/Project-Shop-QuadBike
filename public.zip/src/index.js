import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import Details from './components/Details/Details';
import Header from './components/Header/Header';


const root = ReactDOM.createRoot(document.getElementById('root'));

const router = createBrowserRouter([
{
  path: "/",
  element: <App />,
},
{
  path: "/details",
  element: <Details />
},
{
  path: "/:id",
  element: <>
  <Header /> <Details /> </>
}
]);

root.render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);