import './App.css';
import Filter from './components/Filter/Filter';
import Header from './components/Header/Header';
import Cart from './components/Cart/Cart';
import { products } from "./products"
import Footer from './components/Footer/Footer';

export default function App() {
  return (
    <div>
      <div className="container">
        <Header />
        <div className='filter-block'>
          <Filter />
        </div>
        <div className='goods'>{products.map((item) => {
          return (
            < Cart
              title={item.title}
              price={item.price}
              image={item.image}
            />
          )
        })}</div>
      </div>
      <div className='bg-main'>
        <Footer />
      </div>
    </div>
  )
};

